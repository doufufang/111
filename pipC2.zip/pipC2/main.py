#!/user/bin/env python
#-*- coding:utf-8 -*-
#by: LiuWei

from mainWindow import Ui_MainWindow
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QWidget
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import cv2
import numpy as np
import time

# from imgProcess import imgProcess

class MyMainWindow(QMainWindow, Ui_MainWindow ):
    emit_image_signal=pyqtSignal(QImage)#创建pyqt信号，指定传递的变量类型为QImage

    def __init__(self, parent=None):  #加parent的意思是便是这是个主窗口
        super(MyMainWindow, self).__init__(parent)
        self.setupUi(self)
        self.img = None          #文件初始为空
        self.grayImg=None
        self.timer_camera = QTimer()#初始化定时器
        self.cap = cv2.VideoCapture(0)#Camera初始化
        self.minRadius = 20
        self.maxRadius = 40

        # self.pushButton.clicked.connect(self.openCamera)
        self.timer_camera.timeout.connect(self.show_pic)
        self.horizontalSlider.valueChanged.connect(self.getMinRadius)
        self.horizontalSlider_2.valueChanged.connect(self.getMaxRadius)
        self.timer_camera.start(10)

    def getMinRadius(self):
        self.minRadius = self.horizontalSlider.value()
        print(self.minRadius)
    def getMaxRadius(self):
        self.maxRadius = self.horizontalSlider_2.value()
        print(self.maxRadius)
    def show_pic(self):
        success, frame = self.cap.read()
        if success:
            show = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.img = show

            grayImg = cv2.cvtColor(show, cv2.COLOR_BGR2GRAY)
            GrayImage = cv2.medianBlur(grayImg, 5)
            th2 = cv2.adaptiveThreshold(GrayImage, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                        cv2.THRESH_BINARY, 3, 5)

            kernel = np.ones((5, 5), np.uint8)
            erosion = cv2.erode(th2, kernel, iterations=1)

            imgray = cv2.Canny(erosion, 30, 100)
            circles = cv2.HoughCircles(imgray, cv2.HOUGH_GRADIENT, 1, 20,
                                       param1=50, param2=30, minRadius=self.minRadius, maxRadius=self.maxRadius)
            try:
                self.num = str(len(circles[0, :]))
                circles = np.uint16(np.around(self.circles))
                for i in circles[0, :]:
                    # draw the outer circle
                    cv2.circle(self.img, (i[0], i[1]), i[2], (0, 255, 0), 2)
                    # draw the center of the circle
                    cv2.circle(self.img, (i[0], i[1]), 2, (0, 0, 255), 3)

            except:
                self.num = '没有'



            showImage = QImage(show.data, show.shape[1], show.shape[0], QImage.Format_RGB888)
            self.label_5.setPixmap(QPixmap.fromImage(showImage))
            self.label_4.setText(self.num)
            self.timer_camera.start(10)
            time.sleep(0.3)
        else:
            print('没有打开摄像头')

    def openCamera(self):
        success, frame = self.cap.read()
        if success:
            show = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            showImage = QImage(show.data, show.shape[1], show.shape[0], QImage.Format_RGB888)
            self.label.setPixmap(QPixmap.fromImage(showImage))
            self.timer_camera.start(10)



if __name__=="__main__":
    app=QApplication(sys.argv)
    win=MyMainWindow()
    win.show()

    sys.exit(app.exec_())